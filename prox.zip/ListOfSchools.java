package com.example.a1614885.prox;

public class ListOfSchools {

}
