package com.example.a1614885.prox;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.a1614885.prox.subjectsStuff.Grade10AccountingActivity;
import com.example.a1614885.prox.subjectsStuff.Grade11AccountingActivity;
import com.example.a1614885.prox.subjectsStuff.Grade12AccountingActivity;
import com.example.a1614885.prox.subjectsStuff.grade10MathematicsActivity;
import com.example.a1614885.prox.subjectsStuff.grade10PhysicsActivity;
import com.example.a1614885.prox.subjectsStuff.grade11MathematicsActivity;
import com.example.a1614885.prox.subjectsStuff.grade11PhysicsActivity;
import com.example.a1614885.prox.subjectsStuff.grade12MathematicsActivity;
import com.example.a1614885.prox.subjectsStuff.grade12PhysicsActivity;


public class SubjectsFragment extends Fragment {

    private View subjectsFragmentView;
    private RelativeLayout grade10Accounting, grade11Accounting, grade12Accounting;
    private RelativeLayout grade10Mathematics, grade11Mathematics, grade12Mathematics;
    private RelativeLayout grade10Physics, grade11Physics, grade12Physics;

    public SubjectsFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {



        subjectsFragmentView = inflater.inflate(R.layout.fragment_subjects, container, false);

        initializeFields();

        setOnClickListeners();

        return subjectsFragmentView;
    }



    private void setOnClickListeners() {

        grade10Accounting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade11Accounting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade12Accounting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade10Mathematics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade11Mathematics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade12Mathematics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent math12Intent = new Intent(getContext(), grade12MathematicsActivity.class);
                startActivity(math12Intent);
            }
        });

        grade10Physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade11Physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Content coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        grade12Physics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent physics12Intent = new Intent(getContext(), grade12PhysicsActivity.class);
                startActivity(physics12Intent);
            }
        });

    }

    private void initializeFields() {

        grade10Accounting = subjectsFragmentView.findViewById(R.id.grade10Accounting);
        grade11Accounting = subjectsFragmentView.findViewById(R.id.grade11Accounting);
        grade12Accounting = subjectsFragmentView.findViewById(R.id.grade12Accounting);
        grade10Mathematics = subjectsFragmentView.findViewById(R.id.grade10Mathematics);
        grade11Mathematics = subjectsFragmentView.findViewById(R.id.grade11Mathematics);
        grade12Mathematics = subjectsFragmentView.findViewById(R.id.grade12Mathematics);
        grade10Physics = subjectsFragmentView.findViewById(R.id.grade10Physics);
        grade11Physics = subjectsFragmentView.findViewById(R.id.grade11Physics);
        grade12Physics = subjectsFragmentView.findViewById(R.id.grade12Physics);
    }

}

