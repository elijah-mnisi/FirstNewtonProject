package com.example.a1614885.prox.schoolNewsFeed;

public class getAnswers {

    private String school;
    private String grade;
    private String displayName;
    private String displayPicture;
    private String caption;
    private String equationSolution;
    private String answerId;

    public getAnswers() {
    }

    public getAnswers(String answerId,String school, String grade, String displayName, String displayPicture, String caption, String equationSolution) {
        this.school = school;
        this.grade = grade;
        this.displayName = displayName;
        this.answerId = answerId;
        this.displayPicture = displayPicture;
        this.caption = caption;
        this.equationSolution = equationSolution;
    }

    public String getAnswerId() {
        return answerId;
    }

    public String getSchool() {
        return school;
    }

    public String getGrade() {
        return grade;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDisplayPicture() {
        return displayPicture;
    }

    public String getCaption() {
        return caption;
    }

    public String getEquationSolution() {
        return equationSolution;
    }
}
