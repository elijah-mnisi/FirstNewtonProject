package com.example.a1614885.prox.schoolNewsFeed;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.a1614885.prox.R;

public class QuestionLikersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_likers);
    }
}
