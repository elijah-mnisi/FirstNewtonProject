package com.example.a1614885.prox.schoolNewsFeed;

public class getNewsFeedComments {

    private String profilePicture;
    private String comment;
    private String timeSent;
    private String username;
    private String commentorId;


    public getNewsFeedComments(){}

    public getNewsFeedComments(String profilePicture, String comment, String username, String timeSent, String commentorId) {
        this.profilePicture = profilePicture;
        this.comment = comment;
        this.timeSent = timeSent;
        this.commentorId = commentorId;
        this.username = username;
    }

    public String getTimeSent() {
        return timeSent;
    }

    public String getCommentorId() {
        return commentorId;
    }

    public String getUsername() {
        return username;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public String getComment() {
        return comment;
    }
}
