package com.example.a1614885.prox.schoolNewsFeed;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a1614885.prox.R;
import com.example.a1614885.prox.profile.SolveProblemsActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import io.github.kexanie.library.MathView;

public class AnswersActivity extends AppCompatActivity {

    private RecyclerView answersRecycler;
    private List<getAnswers> answersList;
    private answersAdapter adapter;
    private FloatingActionButton answerFAB;
    private RelativeLayout replyRelative;
    private int fabState = 0; //this is edit mode
    private EditText replyEditText;
    private Button calculator, verifiedMath, verifiedMathRed;
    private String equationSolution = "@NonNull_!Existence";
    private String postId;
    private String displayPicture, displayName, userId, caption, school, grade;

    private MathView answersQuestionMath;
    private TextView description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answers);
        initializeFields();

        controlAppBar();

        if(getIntent().hasExtra("equationSolution")){
            equationSolution = getIntent().getExtras().get("equationSolution").toString();
            verifiedMath.setVisibility(View.VISIBLE);
            verifiedMathRed.setVisibility(View.GONE);
            fabState = 1;
            openKeyBoard();
        }else{
            noSolutionAlert();
        }

        collectAnswer();

        answerFAB.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View view) {

                if(fabState == 0){

                    fabState = 1; //this is send mode
                    openKeyBoard();

                }else{

                    fabState = 0;

                    caption = replyEditText.getText().toString().trim();

                    sendAnswer();
                    replyRelative.setVisibility(View.INVISIBLE);
                    answerFAB.setImageDrawable(getResources().getDrawable(R.drawable.ic_edit_black_24dp));
                    closeKeyBoard();

                }

            }
        });

        calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendToSolve();
            }
        });

    }

    private void controlAppBar() {

        final CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.answersCollapsingToolbarLayout);
        AppBarLayout appBarLayout = findViewById(R.id.answersAppBarLayout);

        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = true;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffset == 0) {
                    collapsingToolbarLayout.setTitle("Answers");
                    isShow = true;
                } else if(isShow) {
                    collapsingToolbarLayout.setTitle(" ");//careful there should a space between double quote otherwise it wont work
                    isShow = false;
                }
            }
        });

    }

    private void noSolutionAlert() {

        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(1000); //You can manage the blinking time with this parameter
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        verifiedMathRed.setVisibility(View.VISIBLE);
        verifiedMath.setVisibility(View.GONE);
        verifiedMathRed.startAnimation(anim);

    }

    private void openKeyBoard() {

        replyRelative.setVisibility(View.VISIBLE);
        replyEditText.requestFocus();
        answerFAB.setImageDrawable(getResources().getDrawable(R.drawable.ic_send_black_24dp));
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(replyEditText, InputMethodManager.SHOW_IMPLICIT);

    }

    private void sendAnswer() {

        if(replyEditText.getText().toString().trim().isEmpty()
                && !getIntent().hasExtra("equationSolution")){
            Toast.makeText(this, "no solution, no comment", Toast.LENGTH_SHORT).show();
        }else if(replyEditText.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "no comment", Toast.LENGTH_SHORT).show();
        }else{

            DatabaseReference answersRef = FirebaseDatabase.getInstance().getReference("home")
                    .child(postId).child("answers");

            String answerKey = answersRef.push().getKey();

            HashMap<String, Object> answerMap = new HashMap<>();
            answerMap.put("school", school);
            answerMap.put("grade", grade);
            answerMap.put("answerId", answerKey);
            answerMap.put("displayName", displayName);
            answerMap.put("displayPicture", displayPicture);
            answerMap.put("caption", caption);
            answerMap.put("userId", userId);
            answerMap.put("equationSolution", equationSolution);

            answersRef.child(answerKey).setValue(answerMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(AnswersActivity.this, "comment sent", Toast.LENGTH_SHORT).show();
                                equationSolution = "@NonNull_!Existence";
                                noSolutionAlert();
                                replyEditText.setText("");
                            }else {
                                Toast.makeText(AnswersActivity.this, "failed to send answer", Toast.LENGTH_SHORT).show();
                                //a dialog and ask the user to resend, this may coz repeatative behaviour assuming user has no bandwidth
                            }
                        }
                    });

        }

    }

    private void sendToSolve() {

        Intent solveIntent = new Intent(AnswersActivity.this, SolveProblemsActivity.class);
        solveIntent.putExtra("postId", postId);
        solveIntent.putExtra("displayPicture", displayPicture);
        solveIntent.putExtra("displayName", displayName);
        solveIntent.putExtra("userId", userId);
        solveIntent.putExtra("school", school);
        solveIntent.putExtra("grade", grade);
        startActivity(solveIntent);

    }

    private void collectAnswer(){

        Query selection = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers")
                .orderByChild("userId").startAt("fHKkHcAJpiOG7Y59KJZZ0TCSUNl1");

        selection.addValueEventListener(valueEventListener);

    }

    private void initializeFields() {

        if(getIntent().hasExtra("postId")){
            postId = getIntent().getExtras().get("postId").toString();
        }

        if(getIntent().hasExtra("displayPicture") && getIntent().hasExtra("userId")
                && getIntent().hasExtra("displayName") && getIntent().hasExtra("grade")
                && getIntent().hasExtra("school")){

            displayPicture = getIntent().getExtras().get("displayPicture").toString();
            displayName = getIntent().getExtras().get("displayName").toString();
            userId = getIntent().getExtras().get("userId").toString();
            school = getIntent().getExtras().get("school").toString();
            grade = getIntent().getExtras().get("grade").toString();

        }

        answersQuestionMath = findViewById(R.id.answersQuestionMath);
        description = findViewById(R.id.description);

        if(getIntent().hasExtra("description") && getIntent().hasExtra("answersQuestionMath")){

            description.setText(getIntent().getExtras().get("description").toString());
            answersQuestionMath.setText(getIntent().getExtras().get("answersQuestionMath").toString());

        }

        answersRecycler = findViewById(R.id.answersRecycler);
        answersRecycler.setHasFixedSize(true);
        answersRecycler.setLayoutManager(new LinearLayoutManager(this));

        answersList = new ArrayList<>();
        adapter = new answersAdapter(this, answersList);
        answersRecycler.setAdapter(adapter);

        calculator = findViewById(R.id.calculator);
        verifiedMath = findViewById(R.id.verifiedMath);
        verifiedMathRed = findViewById(R.id.verifiedMathRed);

        answerFAB = findViewById(R.id.answerFAB);
        replyRelative = findViewById(R.id.replyRelative);

        replyEditText = findViewById(R.id.replyEditText);

    }

    private void closeKeyBoard() {

        View view = this.getCurrentFocus();
        if(view != null){
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }

    class answersAdapter extends RecyclerView.Adapter<answersAdapter.answersViewHolder>{

        private Context mContext;
        private List<getAnswers> answersList;

        public answersAdapter(Context mContext, List<getAnswers> answersList) {
            this.mContext = mContext;
            this.answersList = answersList;
        }

        @Override
        public answersViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

            View view = LayoutInflater.from(mContext).inflate(R.layout.answer_layout, viewGroup, false);

            return new answersViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final answersViewHolder holder, final int position) {
            final getAnswers model = answersList.get(position);

            DatabaseReference deVotesRef = FirebaseDatabase.getInstance().getReference("home")
                    .child(postId).child("answers").child(model.getAnswerId()).child("voteDown");

            DatabaseReference voteRef = FirebaseDatabase.getInstance().getReference("home")
                    .child(postId).child("answers").child(model.getAnswerId()).child("voteUp");

            voteRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.exists()){
                        holder.totalVotes.setText(String.valueOf(dataSnapshot.getChildrenCount()));
                    }else {
                        holder.totalVotes.setText("0");
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            deVotesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.exists()){
                        holder.totalDeVotes.setText(String.valueOf(dataSnapshot.getChildrenCount()));
                    }else{
                        holder.totalDeVotes.setText("0");
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            checkVoteUpState(model, holder);
            checkVoteDownState(model, holder);

            holder.replyAnswer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sendToReplies();
                }
            });

            if(model.getEquationSolution().equals("@NonNull_!Existence")){
                holder.showSolution.setVisibility(View.GONE);
            }

            holder.showSolution.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showSolutionDialog(model.getEquationSolution());
                }
            });

            holder.voteUp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    voteQuestion(model, holder);
                }
            });

            holder.voteDown.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    deVoteQuestion(model, holder);
                }
            });

            holder.solvedCaption.setText(model.getCaption());
            holder.solverName.setText(model.getDisplayName());
            Picasso.get().load(model.getDisplayPicture())
                    .placeholder(R.drawable.ic_person_black_24dp)
                    .into(holder.solverProfilePicture);
        }

        @Override
        public int getItemCount() {
            return answersList.size();
        }

        class answersViewHolder extends RecyclerView.ViewHolder{

            private Button voteUp, voteDown, replyAnswer;
            private CircleImageView solverProfilePicture;
            private TextView solverName, solvedCaption, totalVotes, numberOfReplies, totalDeVotes;
            private Button showSolution;

            public answersViewHolder(View itemView) {
                super(itemView);

                showSolution = itemView.findViewById(R.id.showSolution);
                voteUp = itemView.findViewById(R.id.voteUp);
                totalDeVotes = itemView.findViewById(R.id.totalDeVotes);
                totalVotes = itemView.findViewById(R.id.totalVotes);
                numberOfReplies = itemView.findViewById(R.id.numberOfReplies);
                voteDown = itemView.findViewById(R.id.voteDown);
                replyAnswer = itemView.findViewById(R.id.replyAnswer);
                solverProfilePicture = itemView.findViewById(R.id.solverProfilePicture);
                solverName = itemView.findViewById(R.id.solverName);
                solvedCaption = itemView.findViewById(R.id.solvedCaption);

            }
        }

    }

    private void checkVoteDownState(getAnswers model, final answersAdapter.answersViewHolder holder) {

        DatabaseReference votesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteDown");

        votesRef.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    ViewCompat.setBackgroundTintList(holder.voteDown, ContextCompat.getColorStateList(AnswersActivity.this, R.color.red));
                }else{
                    ViewCompat.setBackgroundTintList(holder.voteDown, ContextCompat.getColorStateList(AnswersActivity.this, R.color.blackTransparent));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void checkVoteUpState(getAnswers model, final answersAdapter.answersViewHolder holder) {

        DatabaseReference votesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteUp");

        votesRef.child(userId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    ViewCompat.setBackgroundTintList(holder.voteUp, ContextCompat.getColorStateList(AnswersActivity.this, R.color.greenLight));
                }else {
                    ViewCompat.setBackgroundTintList(holder.voteUp, ContextCompat.getColorStateList(AnswersActivity.this, R.color.blackTransparent));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void voteQuestion(getAnswers model, answersAdapter.answersViewHolder holder) {

        DatabaseReference deVotesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteDown");
        deVotesRef.child(userId).removeValue();

        HashMap<String, Object> likeInfo = new HashMap<>();
        likeInfo.put("displayName", displayName);
        likeInfo.put("displayPicture", displayPicture);
        likeInfo.put("grade", grade);
        likeInfo.put("school", school);

        DatabaseReference votesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteUp");
        votesRef.child(userId).setValue(likeInfo);

        ViewCompat.setBackgroundTintList(holder.voteDown, ContextCompat.getColorStateList(this, R.color.blackTransparent));
        ViewCompat.setBackgroundTintList(holder.voteUp, ContextCompat.getColorStateList(this, R.color.greenLight));

    }

    private void deVoteQuestion(getAnswers model, answersAdapter.answersViewHolder holder) {

        DatabaseReference votesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteUp");
        votesRef.child(userId).removeValue();

        DatabaseReference deVotesRef = FirebaseDatabase.getInstance().getReference("home")
                .child(postId).child("answers").child(model.getAnswerId()).child("voteDown");

        HashMap<String, Object> likeInfo = new HashMap<>();
        likeInfo.put("displayName", displayName);
        likeInfo.put("displayPicture", displayPicture);
        likeInfo.put("grade", grade);
        likeInfo.put("school", school);

        deVotesRef.child(userId).setValue(likeInfo);

        ViewCompat.setBackgroundTintList(holder.voteUp, ContextCompat.getColorStateList(this, R.color.blackTransparent));
        ViewCompat.setBackgroundTintList(holder.voteDown, ContextCompat.getColorStateList(this, R.color.red));

    }

    private void showSolutionDialog(String solution) {

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.view_question_layout);

        MathView mathViewer = dialog.findViewById(R.id.mathViewer);
        mathViewer.setText(solution);

        dialog.show();

    }

    private void sendToReplies() {

        Intent viewRepliesIntent = new Intent(AnswersActivity.this, ViewRepliesActivity.class);
        startActivity(viewRepliesIntent);

    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){

                answersList.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    getAnswers answers = snapshot.getValue(getAnswers.class);
                    answersList.add(answers);
                }
            }

            adapter.notifyDataSetChanged();
        }

        @Override
        public void onCancelled(DatabaseError databaseError) {

        }
    };
}
