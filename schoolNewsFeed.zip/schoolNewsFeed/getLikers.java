package com.example.a1614885.prox.schoolNewsFeed;

public class getLikers {

    private String profilePicture;
    private String username;

    public getLikers(){}

    public getLikers(String profilePicture, String username) {
        this.profilePicture = profilePicture;
        this.username = username;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public String getUsername() {
        return username;
    }
}
