package com.example.a1614885.prox.schoolNewsFeed;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.a1614885.prox.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewRepliesActivity extends AppCompatActivity {

    private RecyclerView repliesRecycler;
    private List<getReplies> repliesList;
    private repliesAdapter adapter;

    private TextView sendReply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_replies);

        initializeFields();

        collectReplies();

    }

    private void collectReplies(){

        Query selections = FirebaseDatabase.getInstance().getReference("testComments")
                .orderByChild("posterId")
                .startAt("name");

        selections.addValueEventListener(valueEventListener);

    }

    private void initializeFields() {

        repliesRecycler = findViewById(R.id.repliesRecycler);
        repliesRecycler.setHasFixedSize(true);
        repliesRecycler.setLayoutManager(new LinearLayoutManager(this));

        repliesList = new ArrayList<>();
        adapter = new repliesAdapter(repliesList, this);
        repliesRecycler.setAdapter(adapter);
        sendReply = findViewById(R.id.sendReply);

    }

    class repliesAdapter extends RecyclerView.Adapter<repliesAdapter.repliesViewHolder>{

        private List<getReplies> repliesList;
        private Context mContext;

        public repliesAdapter(List<getReplies> repliesList, Context mContext) {
            this.repliesList = repliesList;
            this.mContext = mContext;
        }

        @Override
        public repliesViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

            View view = LayoutInflater.from(mContext).inflate(R.layout.comment_layout, viewGroup, false);

            return new repliesViewHolder(view);
        }

        @Override
        public void onBindViewHolder(repliesViewHolder holder, int position) {
            getReplies model = repliesList.get(position);

            if(model.getReplierName().equals("elijah")){
                holder.myRelative.setVisibility(View.VISIBLE);
                holder.otherRelative.setVisibility(View.GONE);
            }else{
                holder.myRelative.setVisibility(View.GONE);
                holder.otherRelative.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public int getItemCount() {
            return repliesList.size();
        }

        class repliesViewHolder extends RecyclerView.ViewHolder{

            private RelativeLayout myRelative, otherRelative;

            public repliesViewHolder(View itemView) {
                super(itemView);

                myRelative = itemView.findViewById(R.id.myRelative);
                otherRelative = itemView.findViewById(R.id.otherRelative);

            }
        }

    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){
                repliesList.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){

                    getReplies replies = snapshot.getValue(getReplies.class);
                    repliesList.add(replies);

                }
            }

            adapter.notifyDataSetChanged();

        }

        @Override
        public void onCancelled(DatabaseError databaseError) {

        }
    };

}
