package com.example.a1614885.prox.schoolNewsFeed;

import android.app.Dialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.a1614885.prox.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.theartofdev.edmodo.cropper.CropImage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import io.github.kexanie.library.MathView;

import static android.app.Activity.RESULT_OK;


public class NewsFeedFragment extends Fragment {


    public NewsFeedFragment() {
    }

    private View fragmentView;
    private RecyclerView newsFeedRecycler;
    private String userId;
    private String displayName;
    private DatabaseReference profileRef;
    private String school;
    private Uri postThisImageUri;
    private String grade;
    private String userProfilePicture;
    private FirebaseRecyclerOptions<getNewsFeed> newsFeedOptions;
    private FirebaseRecyclerAdapter<getNewsFeed, newsFeedViewHolder> newsFeedAdapter;
    private DatabaseReference newsFeedRef;
    private Date dateTime;
    private String currentDate;
    private FloatingActionButton fab;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        fragmentView = inflater.inflate(R.layout.fragment_news_feed, container, false);

        initializeFields();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        newsFeedRef = FirebaseDatabase.getInstance().getReference("home");

        newsFeedOptions = new FirebaseRecyclerOptions.Builder<getNewsFeed>()
                .setQuery(newsFeedRef, getNewsFeed.class).build();

        newsFeedAdapter = new FirebaseRecyclerAdapter<getNewsFeed, newsFeedViewHolder>(newsFeedOptions) {
            @Override
            protected void onBindViewHolder(final newsFeedViewHolder holder, final int position, final getNewsFeed model) {

                final String postId = model.getPostId();

                holder.answer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sendToAnswer(postId, model.getPostDescription(), model.getQuestion());
                    }
                });

                holder.answersIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sendToAnswer(postId, model.getPostDescription(), model.getQuestion());
                    }
                });

                holder.votesNumber.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sendToLikers();
                    }
                });

                holder.vote.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ViewCompat.setBackgroundTintList(holder.vote, ContextCompat.getColorStateList(getContext(), android.R.color.holo_blue_light));
                    }
                });




                /********************************POST_TYPE_MATH************************************/

                if(model.getPostType().equals("math")){

                    holder.description.setText(model.getPostDescription());
                    holder.viewQuestion.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            showQuestion(model.getQuestion());
                        }
                    });

                }

                /**********************************************************************************/

            }

            @Override
            public newsFeedViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

                View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_layout, viewGroup, false);

                return new newsFeedViewHolder(view);
            }
        };

        newsFeedAdapter.startListening();
        newsFeedRecycler.setAdapter(newsFeedAdapter);

        return fragmentView;
    }

    private void showQuestion(String description) {

        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.view_question_layout);

        MathView mathViewer = dialog.findViewById(R.id.mathViewer);
        mathViewer.setText(description);

        dialog.show();

    }

    private void sendToLikers() {

        Intent likersIntent = new Intent(getContext(), QuestionLikersActivity.class);
        startActivity(likersIntent);

    }

    private void sendToAnswer(String postId, String description, String answersQuestionMath) {

        Intent answerIntent = new Intent(getContext(), AnswersActivity.class);
        answerIntent.putExtra("postId", postId);
        answerIntent.putExtra("description", description);
        answerIntent.putExtra("answersQuestionMath", answersQuestionMath);
        answerIntent.putExtra("displayPicture", userProfilePicture);
        answerIntent.putExtra("userId", userId);
        answerIntent.putExtra("displayName", displayName);
        answerIntent.putExtra("grade", grade);
        answerIntent.putExtra("school", school);
        startActivity(answerIntent);

    }

    private void openGallery() {

        Intent openQuestionIntent = new Intent();
        openQuestionIntent.setAction(Intent.ACTION_GET_CONTENT);
        openQuestionIntent.setType("image/*");
        startActivityForResult(openQuestionIntent, 1);

    }

    private String getPostTimeDifference(String postTime){

        dateTime = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        String timeNow = timeFormat.format(dateTime);

        int totalPostTime = 0;
        int totalTimeNow = 0;

        String hours = "";
        String hoursNow = "";
        String minutes = "";
        String minutesNow = "";

        for(int count = 0; count < 2; count++){
            hours = hours + postTime.charAt(count);
            hoursNow = hoursNow + timeNow.charAt(count);
        }

        if(postTime.endsWith("PM") && !hours.equals("12")){
            hours = (12 + Integer.parseInt(hours)) + "";
        }if(timeNow.endsWith("PM") && !hoursNow.equals("12")){
            hoursNow = (12 + Integer.parseInt(hoursNow)) + "";
        }if(postTime.endsWith("AM") && hours.equals("12")){
            hours = (12 + Integer.parseInt(hours)) + "";
        }if(timeNow.endsWith("AM") && hoursNow.equals("12")){
            hoursNow = (12 + Integer.parseInt(hoursNow)) + "";
        }

        for(int count = 3; count < 5; count++){
            minutes = minutes + postTime.charAt(count);
            minutesNow = minutesNow + timeNow.charAt(count);
        }

        totalPostTime = (Integer.parseInt(hours)*60) + Integer.parseInt(minutes);
        totalTimeNow = (Integer.parseInt(hoursNow)*60) + Integer.parseInt(minutesNow);

        String output = "";
        if(totalTimeNow >= totalPostTime){
            int totalMinutes = totalTimeNow - totalPostTime;
            int totalHours = 0;
            while(totalMinutes >= 60){
                totalMinutes = totalMinutes - 60;
                totalHours = totalHours + 1;
            }

            if(totalMinutes == 0 && totalHours == 0){
                output = "Just now";
            }else if(totalHours == 0){
                output = totalMinutes + " " + "minutes ago";
            }else if(totalHours == 1){
                output = totalHours + " " + "hour ago";
            }else{
                output = totalHours + " " + "hours ago";
            }
        }else {
            output = "Yesterday, " + postTime;
        }

        return output;
    }

    /**private void sendComment(final newsFeedViewHolder holder, getNewsFeed model) {

        dateTime = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        String currentTime = timeFormat.format(dateTime);

        if(holder.typeComment.getText().toString().trim().isEmpty()){
            Toast.makeText(getContext(), "type comment", Toast.LENGTH_SHORT).show();
        }else{

            //DatabaseReference commentsRef = newsFeedRef.child(model.getPostId()).child("comments");
            String comment = holder.typeComment.getText().toString().trim();

            //String commentKey = commentsRef.push().getKey();

            HashMap<String, Object> commentInfo = new HashMap<>();
            commentInfo.put("comment", comment);
            commentInfo.put("profilePicture", userProfilePicture);
            commentInfo.put("username", displayName);
            commentInfo.put("commentorId", userId);
            commentInfo.put("timeSent", currentTime);

            //commentsRef.child(commentKey).setValue(commentInfo)
            .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(getContext(), "comment sent", Toast.LENGTH_SHORT).show();
                        holder.typeComment.setText("");
                    }else{
                        Toast.makeText(getContext(), "comment not sent", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }

    }**/

    private void likePost(newsFeedViewHolder holder, getNewsFeed model, int position) {

        HashMap<String, Object> likeInfo = new HashMap<>();
        likeInfo.put("username", displayName);
        likeInfo.put("profilePicture", userProfilePicture);

        DatabaseReference postRef = newsFeedAdapter.getSnapshots().getSnapshot(position).getRef();
        postRef.child("likes").child(userId).setValue(likeInfo);

        holder.postLike.setText("Liked");
        holder.postLike.setTextColor(getResources().getColor(R.color.colorPrimaryLight));

    }

    @Override
    public void onStart() {
        super.onStart();
        if(newsFeedAdapter != null){
            newsFeedAdapter.startListening();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == RESULT_OK && data != null){

            Uri tempUri = data.getData();

            CropImage.activity(tempUri)
                    .setAspectRatio(16,9)
                    .start(getContext(), this);

        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK){
                postThisImageUri = result.getUri();
                Intent askQuestionIntent = new Intent(getContext(), AskQuestionActivity.class);
                askQuestionIntent.putExtra("imageUri", postThisImageUri.toString());
                askQuestionIntent.putExtra("userId", userId);
                askQuestionIntent.putExtra("school", school);
                askQuestionIntent.putExtra("grade", grade);
                askQuestionIntent.putExtra("userProfilePicture", userProfilePicture);
                askQuestionIntent.putExtra("displayName", displayName);
                askQuestionIntent.putExtra("currentDate", currentDate);
                startActivity(askQuestionIntent);
            }
        }

    }

    private void initializeFields() {

        fab = fragmentView.findViewById(R.id.fab);

        newsFeedRecycler = fragmentView.findViewById(R.id.newsFeedRecycler);
        newsFeedRecycler.setHasFixedSize(true);

        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        manager.setReverseLayout(true);
        manager.setStackFromEnd(true);
        newsFeedRecycler.setLayoutManager(manager);

        if(FirebaseAuth.getInstance().getCurrentUser() != null){

            userProfilePicture = FirebaseAuth.getInstance().getCurrentUser().getPhotoUrl().toString();
            userId = FirebaseAuth.getInstance().getUid();

            displayName = FirebaseAuth.getInstance().getCurrentUser().getDisplayName();

            String shortName = "" + displayName.toLowerCase().charAt(0);
            for(int count = 1; count < 3; count++){
                shortName = shortName + displayName.charAt(count);
            }

            profileRef = FirebaseDatabase.getInstance().getReference("Users").child(shortName).child(userId);
            profileRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.exists()){
                        try{
                            school = dataSnapshot.child("school").getValue().toString();
                            grade = dataSnapshot.child("grade").getValue().toString();
                        }catch (Exception e){}
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {}
            });


        }

        dateTime = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("d-M-y");
        currentDate = dateFormat.format(dateTime);

    }

    private class newsFeedViewHolder extends RecyclerView.ViewHolder{

        Button postLike, viewQuestion;
        TextView description;
        TextView votesNumber;
        Button vote, answersIcon;
        RelativeLayout answer;

        public newsFeedViewHolder(View itemView) {
            super(itemView);

            votesNumber = itemView.findViewById(R.id.votesNumber);
            vote = itemView.findViewById(R.id.vote);
            answer = itemView.findViewById(R.id.answer);
            answersIcon = itemView.findViewById(R.id.qNa);
            viewQuestion = itemView.findViewById(R.id.viewQuestion);
            description = itemView.findViewById(R.id.description);

        }

    }

}
