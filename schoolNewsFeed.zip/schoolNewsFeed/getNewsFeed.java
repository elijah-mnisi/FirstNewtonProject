package com.example.a1614885.prox.schoolNewsFeed;

public class getNewsFeed {

    private String postDescription;
    private String postType;
    private String question;
    private String subjectType;
    private String postId;

    public getNewsFeed() {
    }

    public getNewsFeed(String postId, String postDescription, String postType, String question, String subjectType) {
        this.postDescription = postDescription;
        this.postId = postId;
        this.postType = postType;
        this.question = question;
        this.subjectType = subjectType;
    }

    public String getPostId() {
        return postId;
    }

    public String getPostDescription() {
        return postDescription;
    }

    public String getPostType() {
        return postType;
    }

    public String getQuestion() {
        return question;
    }

    public String getSubjectType() {
        return subjectType;
    }
}
