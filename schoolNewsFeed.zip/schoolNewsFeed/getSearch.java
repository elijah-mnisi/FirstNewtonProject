package com.example.a1614885.prox.schoolNewsFeed;

public class getSearch {

    private String username;
    private String school;
    private String profilePicture;
    private String userId;

    public getSearch() {
    }

    public getSearch(String userId, String username, String school, String profilePicture) {
        this.username = username;
        this.school = school;
        this.profilePicture = profilePicture;
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public String getUserId() {
        return userId;
    }

    public String getSchool() {
        return school;
    }

    public String getProfilePicture() {
        return profilePicture;
    }
}
