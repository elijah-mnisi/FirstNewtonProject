package com.example.a1614885.prox.schoolNewsFeed;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.a1614885.prox.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class LikesActivity extends AppCompatActivity {

    private RecyclerView likesRecycler;
    private FirebaseRecyclerOptions<getLikers> likesOptions;
    private FirebaseRecyclerAdapter<getLikers, likesViewHolder> likesAdapter;
    private DatabaseReference likesRef;
    private String school;
    private String grade;
    private String postId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_likes);

        initializeFields();

        school = getIntent().getExtras().get("school").toString();
        grade = getIntent().getExtras().get("grade").toString();
        postId = getIntent().getExtras().get("postId").toString();

        likesRef = FirebaseDatabase.getInstance().getReference("homePost")
                .child(school).child("12").child("posts").child(postId).child("likes");

        likesOptions = new FirebaseRecyclerOptions.Builder<getLikers>().setQuery(likesRef, getLikers.class).build();

        likesAdapter = new FirebaseRecyclerAdapter<getLikers, likesViewHolder>(likesOptions) {
            @Override
            protected void onBindViewHolder(likesViewHolder holder, int position, getLikers model) {
                holder.likerName.setText(model.getUsername());
                try{
                    Picasso.get().load(model.getProfilePicture())
                            .placeholder(R.drawable.ic_photo_black_24dp)
                            .resize(72,72)
                            .into(holder.likerPicture);
                }catch (Exception e){
                    holder.likerPicture.setImageResource(R.drawable.ic_photo_black_24dp);
                }
            }

            @Override
            public likesViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

                View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.likers_layout, viewGroup, false);

                return new likesViewHolder(view);
            }
        };

        likesAdapter.startListening();
        likesRecycler.setAdapter(likesAdapter);

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(likesAdapter != null){
            likesAdapter.startListening();
        }
    }

    private void initializeFields() {

        likesRecycler = findViewById(R.id.likesRecycler);
        likesRecycler.setHasFixedSize(true);
        likesRecycler.setLayoutManager(new LinearLayoutManager(this));

    }

    private class likesViewHolder extends RecyclerView.ViewHolder{

        private CircleImageView likerPicture;
        private TextView likerName;

        public likesViewHolder(View itemView) {
            super(itemView);

            likerPicture = itemView.findViewById(R.id.likerPicture);
            likerName = itemView.findViewById(R.id.likerName);

        }
    }
}
