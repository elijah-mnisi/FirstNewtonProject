package com.example.a1614885.prox.schoolNewsFeed;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


import com.example.a1614885.prox.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class AskQuestionActivity extends AppCompatActivity {

    private Toolbar askQuestionToolbar;
    private EditText postCaption;
    private ImageButton changeImage;
    private ImageView ImageQuestion;
    private Button postIt;

    private String userId;
    private String school;
    private Uri postThisImageUri;
    private String grade;
    private Date dateTime;
    private String userProfilePicture;
    private String displayName;
    private String currentDate;

    private ProgressDialog progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_question);

        closeKeyBoard();

        postThisImageUri = Uri.parse(getIntent().getExtras().get("imageUri").toString());

        initializeFields();
        setSupportActionBar(askQuestionToolbar);

        ImageQuestion.setImageURI(postThisImageUri);

        changeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectNewImage();
            }
        });

        postIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postQuestion();
            }
        });
    }

    private void selectNewImage() {

        Intent openQuestionIntent = new Intent();
        openQuestionIntent.setAction(Intent.ACTION_GET_CONTENT);
        openQuestionIntent.setType("image/*");
        startActivityForResult(openQuestionIntent, 1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == RESULT_OK && data != null){

            Uri tempUri = data.getData();

            CropImage.activity(tempUri)
                    .setAspectRatio(1,1)
                    .start(this);

        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK){
                postThisImageUri = result.getUri();
                ImageQuestion.setImageURI(postThisImageUri);
            }
        }
    }

    private void postQuestion(){

        final String caption = postCaption.getText().toString().trim();

        if(caption.isEmpty()){
            postCaption.setError("post description is required");
            postCaption.requestFocus();
        }else{

            progressBar.setTitle("Uploading post");
            progressBar.setMessage("please wait");
            progressBar.setCanceledOnTouchOutside(false);
            progressBar.show();
            closeKeyBoard();

            final StorageReference postFilePath = FirebaseStorage.getInstance().getReference("homePost")
                    .child(school)
                    .child(userId)
                    .child(System.currentTimeMillis() + "jpg");

            postFilePath.putFile(postThisImageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(Task<UploadTask.TaskSnapshot> task) {
                    if(task.isSuccessful()){
                        postFilePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String postUri = uri.toString();

                                DatabaseReference postRef = FirebaseDatabase.getInstance().getReference("homePost")
                                        .child(school)
                                        .child(grade)
                                        .child("posts");

                                dateTime = new Date();
                                SimpleDateFormat day = new SimpleDateFormat("dd");
                                SimpleDateFormat time = new SimpleDateFormat("hh:mm a");
                                String dateToday = day.format(dateTime);
                                String timeSent = time.format(dateTime);

                                String postKey = postRef.push().getKey();

                                HashMap<String, Object> postInfo = new HashMap<>();
                                postInfo.put("posterProfilePicture", userProfilePicture);
                                postInfo.put("imagePost", postUri);
                                postInfo.put("posterName", displayName);
                                postInfo.put("postDate", currentDate);
                                postInfo.put("dateToday", dateToday);
                                postInfo.put("timeSent", timeSent);
                                postInfo.put("postId", postKey);
                                postInfo.put("postDescription", caption);
                                postInfo.put("posterId", userId);

                                postRef.child(postKey).setValue(postInfo)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(Task<Void> task) {
                                                if(task.isSuccessful()){
                                                    onBackPressed();
                                                    progressBar.dismiss();
                                                }else{
                                                    Toast.makeText(AskQuestionActivity.this, "upload was unsuccessful", Toast.LENGTH_SHORT).show();
                                                    progressBar.dismiss();
                                                }
                                            }
                                        });
                            }
                        });
                    }
                }
            });
        }

    }

    private void closeKeyBoard() {

        View view = this.getCurrentFocus();
        if(view != null){
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }

    private void initializeFields() {

        askQuestionToolbar = findViewById(R.id.askQuestionToolbar);
        postCaption = findViewById(R.id.postCaption);
        changeImage = findViewById(R.id.changeImage);
        postIt = findViewById(R.id.postIt);
        ImageQuestion = findViewById(R.id.ImageQuestion);

        userId = getIntent().getExtras().get("userId").toString();
        school = getIntent().getExtras().get("school").toString();
        grade = getIntent().getExtras().get("grade").toString();
        userProfilePicture = getIntent().getExtras().get("userProfilePicture").toString();
        displayName = getIntent().getExtras().get("displayName").toString();
        currentDate = getIntent().getExtras().get("currentDate").toString();

        progressBar = new ProgressDialog(this);

    }
}
