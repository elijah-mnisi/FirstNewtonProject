package com.example.a1614885.prox.schoolNewsFeed;

public class getReplies {

    private String replierProfile;
    private String replyMessage;
    private String replierName;
    private String replyTime;
    private String replierId;

    public getReplies() {
    }

    public getReplies(String replierProfile, String replyMessage, String replierName, String replyTime, String replierId) {
        this.replierProfile = replierProfile;
        this.replyMessage = replyMessage;
        this.replierName = replierName;
        this.replyTime = replyTime;
        this.replierId = replierId;
    }

    public String getReplierProfile() {
        return replierProfile;
    }

    public String getReplyMessage() {
        return replyMessage;
    }

    public String getReplierName() {
        return replierName;
    }

    public String getReplyTime() {
        return replyTime;
    }

    public String getReplierId() {
        return replierId;
    }
}
