package com.example.a1614885.prox.schoolNewsFeed;

import android.app.Dialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a1614885.prox.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class NewsFeedCommentsActivity extends AppCompatActivity {

    private RecyclerView newsFeedCommentsRecycler;
    private FirebaseRecyclerOptions<getNewsFeedComments> firebaseRecyclerOptions;
    private FirebaseRecyclerAdapter<getNewsFeedComments, newFeedCommentsViewHolder> firebaseRecyclerAdapter;
    private DatabaseReference newsFeedCommentsRef;

    private EditText typeNewsComment;
    private ImageButton newsCommentSend;

    private String school;
    private String grade;
    private String postId;

    private String userProfilePicture;
    private String displayName;
    private String userId;

    private int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_feed_comments);

        initializeFields();

        userId = FirebaseAuth.getInstance().getUid();
        displayName = FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
        userProfilePicture = FirebaseAuth.getInstance().getCurrentUser().getPhotoUrl().toString();

        typeNewsComment = findViewById(R.id.typeNewsComment);
        newsCommentSend = findViewById(R.id.newsCommentSend);

         school = getIntent().getExtras().get("school").toString();
         grade = getIntent().getExtras().get("grade").toString();
         postId = getIntent().getExtras().get("postId").toString();

        newsCommentSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendComment();
            }
        });

        newsFeedCommentsRef = FirebaseDatabase.getInstance().getReference("homePost")
                .child(school).child(grade).child("posts").child(postId).child("comments");

        firebaseRecyclerOptions = new FirebaseRecyclerOptions.Builder<getNewsFeedComments>().setQuery(newsFeedCommentsRef, getNewsFeedComments.class).build();
        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<getNewsFeedComments, newFeedCommentsViewHolder>(firebaseRecyclerOptions) {
            @Override
            protected void onBindViewHolder(newFeedCommentsViewHolder holder, int position, getNewsFeedComments model) {

                if(model.getCommentorId().equals(userId)){
                    holder.myRelative.setVisibility(View.VISIBLE);
                    holder.commentProfile.setVisibility(View.GONE);
                    holder.otherRelative.setVisibility(View.GONE);

                    holder.myCommentText.setText(model.getComment());
                    holder.myTimeSent.setText(model.getTimeSent());


                }else{

                    holder.myRelative.setVisibility(View.GONE);
                    holder.otherRelative.setVisibility(View.VISIBLE);
                    holder.commentProfile.setVisibility(View.VISIBLE);

                    holder.nameText.setText(model.getUsername());
                    holder.timeSent.setText(model.getTimeSent());
                    holder.commentText.setText(model.getComment());
                    try{
                        Picasso.get().load(model.getProfilePicture())
                                .resize(30,30)
                                .placeholder(R.drawable.ic_person_black_24dp)
                                .into(holder.commentProfile);
                    }catch (Exception e){
                        holder.commentProfile.setImageResource(R.drawable.ic_person_black_24dp);
                    }
                }

                if(flag == 0){
                    newsFeedCommentsRecycler.smoothScrollToPosition(firebaseRecyclerAdapter.getItemCount());
                }else{
                    flag = 0;
                }
            }

            @Override
            public newFeedCommentsViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

                View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.comment_layout, viewGroup, false);

                return new newFeedCommentsViewHolder(view);
            }

        };

        typeNewsComment.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                newsFeedCommentsRecycler.smoothScrollToPosition(firebaseRecyclerAdapter.getItemCount());
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                newsFeedCommentsRecycler.smoothScrollToPosition(firebaseRecyclerAdapter.getItemCount());
            }

            @Override
            public void afterTextChanged(Editable s) {
                newsFeedCommentsRecycler.smoothScrollToPosition(firebaseRecyclerAdapter.getItemCount());
            }
        });

        firebaseRecyclerAdapter.startListening();
        newsFeedCommentsRecycler.setAdapter(firebaseRecyclerAdapter);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder1) {
                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int i) {
                confirmDelete(firebaseRecyclerAdapter.getSnapshots().getSnapshot(viewHolder.getAdapterPosition()).getRef(), viewHolder.getAdapterPosition(),
                        firebaseRecyclerAdapter.getSnapshots().getSnapshot(viewHolder.getAdapterPosition()).child("commentorId").getValue());
            }
        }).attachToRecyclerView(newsFeedCommentsRecycler);

    }

    private void confirmDelete(final DatabaseReference ref, final int adapterPosition, Object commentorId) {

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.delete_comment);
        dialog.setCanceledOnTouchOutside(false);

        Button yesDelete = dialog.findViewById(R.id.yesDelete);
        Button noDelete = dialog.findViewById(R.id.noDelete);

        yesDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.removeValue();
                dialog.dismiss();
                Toast.makeText(NewsFeedCommentsActivity.this, "comment deleted", Toast.LENGTH_SHORT).show();
            }
        });

        noDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                firebaseRecyclerAdapter.notifyItemChanged(adapterPosition);
                flag = 1;
            }
        });

        if(commentorId.equals(userId)) {
            dialog.show();
        }else{
            Toast.makeText(this, "you cannot delete this comment", Toast.LENGTH_SHORT).show();
            firebaseRecyclerAdapter.notifyItemChanged(adapterPosition);
            flag = 1;
        }

    }

    private void sendComment() {

        if(typeNewsComment.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "type comment", Toast.LENGTH_SHORT).show();
        }else{

            Date date = new Date();
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
            String currentTime = timeFormat.format(date);

            String comment = typeNewsComment.getText().toString().trim();

            DatabaseReference commentRef = FirebaseDatabase.getInstance().getReference("homePost")
                    .child(school).child(grade).child("posts").child(postId).child("comments");

            String commentKey = commentRef.push().getKey();

            HashMap<String, Object> commentInfo = new HashMap<>();
            commentInfo.put("comment", comment);
            commentInfo.put("profilePicture", userProfilePicture);
            commentInfo.put("commentorId", userId);
            commentInfo.put("username", displayName);
            commentInfo.put("timeSent", currentTime);

            commentRef.child(commentKey).setValue(commentInfo)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(Task<Void> task) {
                            if(task.isSuccessful()){
                                newsFeedCommentsRecycler.smoothScrollToPosition(firebaseRecyclerAdapter.getItemCount());
                                typeNewsComment.setText("");
                            }else{
                                Toast.makeText(NewsFeedCommentsActivity.this, "comment not sent", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if(firebaseRecyclerAdapter != null){
            firebaseRecyclerAdapter.startListening();
        }
    }

    private void initializeFields() {

        newsFeedCommentsRecycler = findViewById(R.id.newsFeedCommentsRecycler);
        newsFeedCommentsRecycler.setHasFixedSize(true);
        newsFeedCommentsRecycler.setLayoutManager(new LinearLayoutManager(this));

    }

    private class newFeedCommentsViewHolder extends RecyclerView.ViewHolder{

        CircleImageView commentProfile;
        TextView nameText, commentText, timeSent, myCommentText, myTimeSent;
        RelativeLayout myRelative, otherRelative;

        public newFeedCommentsViewHolder(View itemView) {
            super(itemView);

            commentProfile = itemView.findViewById(R.id.commentProfile);
            nameText = itemView.findViewById(R.id.nameText);
            commentText = itemView.findViewById(R.id.commentText);
            timeSent = itemView.findViewById(R.id.timeSent);
            myCommentText = itemView.findViewById(R.id.myCommentText);
            myTimeSent = itemView.findViewById(R.id.myTimeSent);
            myRelative = itemView.findViewById(R.id.myRelative);
            otherRelative = itemView.findViewById(R.id.otherRelative);

        }
    }
}
