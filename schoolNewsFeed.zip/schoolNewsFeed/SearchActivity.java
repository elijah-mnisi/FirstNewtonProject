package com.example.a1614885.prox.schoolNewsFeed;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.a1614885.prox.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class SearchActivity extends AppCompatActivity {

    private EditText searchBar;
    private RecyclerView searchRecycler;
    private List<getSearch> searchList;
    private searchAdapter adapter;

    private String myDisplayName, myUserId, myDisplayPicture;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        initializeFields();

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                check();
            }
        });

    }

    private void check() {

        if(!searchBar.getText().toString().trim().isEmpty() && searchBar.getText().toString().length() >= 3){

            String shortName = "" + searchBar.getText().toString().toLowerCase().charAt(0);
            for(int count = 1; count < 3; count++){
                shortName = shortName + searchBar.getText().toString().toLowerCase().charAt(count);
            }

            searchCollection(shortName, searchBar.getText().toString().toLowerCase().trim());
        }else if(searchBar.getText().toString().trim().isEmpty()){
            searchList.clear();
        }

    }

    private void searchCollection(String shortName, String searchText) {

        Query searchQuery = FirebaseDatabase.getInstance().getReference("Users")
                .child(shortName)
                .orderByChild("username").startAt(searchText);
        searchQuery.addValueEventListener(searchListener);

    }

    private class searchAdapter extends RecyclerView.Adapter<searchAdapter.searchViewHolder>{

        private List<getSearch> searchList;

        public searchAdapter(List<getSearch> searchList) {
            this.searchList = searchList;
        }

        @NonNull
        @Override
        public searchViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.groups_layout, viewGroup, false);
            return new searchViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull searchViewHolder holder, int position) {
            final getSearch model = searchList.get(position);

            Picasso.get().load(model.getProfilePicture()).into(holder.groupPicture);
            holder.groupName.setText(model.getUsername());
            holder.groupStatus.setText(model.getSchool());

            holder.groupRelativeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sendToUserProfile(model.getUserId(), model.getUsername(), model.getProfilePicture());
                }
            });
        }

        @Override
        public int getItemCount() {
            return searchList.size();
        }

        private class searchViewHolder extends RecyclerView.ViewHolder{

            private TextView groupName, groupStatus;
            private CircleImageView groupPicture;
            private RelativeLayout groupRelativeLayout;

            public searchViewHolder(@NonNull View itemView) {
                super(itemView);

                groupName = itemView.findViewById(R.id.groupName);
                groupStatus = itemView.findViewById(R.id.groupStatus);
                groupPicture = itemView.findViewById(R.id.groupPicture);
                groupRelativeLayout = itemView.findViewById(R.id.groupRelativeLayout);

            }
        }

    }

    private void sendToUserProfile(String userId, String username, String profilePicture) {

        String shortName = "" + username.toLowerCase().charAt(0);
        for(int count = 1; count < 3; count++){
            shortName = shortName + username.toLowerCase().charAt(count);
        }

        String myShortName = "" + myDisplayName.toLowerCase().charAt(0);
        for(int count = 1; count < 3; count++){
            myShortName = myShortName + myDisplayName.toLowerCase().charAt(count);
        }

        Intent userProfileIntent = new Intent(SearchActivity.this, UserProfileActivity.class);
        userProfileIntent.putExtra("userId", userId);
        userProfileIntent.putExtra("shortName", shortName);
        userProfileIntent.putExtra("displayName", username);
        userProfileIntent.putExtra("displayPicture", profilePicture);
        userProfileIntent.putExtra("myShortName", myShortName);
        userProfileIntent.putExtra("myDisplayName", myDisplayName);
        userProfileIntent.putExtra("myDisplayPicture", myDisplayPicture);
        userProfileIntent.putExtra("myUserId", myUserId);
        startActivity(userProfileIntent);
    }

    ValueEventListener searchListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

            searchList.clear();
            if(dataSnapshot.exists()){
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    getSearch search = snapshot.getValue(getSearch.class);
                    searchList.add(search);
                }
            }
            adapter.notifyDataSetChanged();
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

    private void initializeFields() {

        searchBar = findViewById(R.id.searchBar);
        searchRecycler = findViewById(R.id.searchRecycler);
        searchRecycler.setHasFixedSize(true);
        searchRecycler.setLayoutManager(new LinearLayoutManager(this));

        searchList = new ArrayList<>();
        adapter = new searchAdapter(searchList);
        searchRecycler.setAdapter(adapter);

        mAuth = FirebaseAuth.getInstance();
        myDisplayName = mAuth.getCurrentUser().getDisplayName();
        myDisplayPicture = mAuth.getCurrentUser().getPhotoUrl().toString();
        myUserId = mAuth.getUid();

    }

}