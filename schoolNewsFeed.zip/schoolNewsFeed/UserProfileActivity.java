package com.example.a1614885.prox.schoolNewsFeed;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.a1614885.prox.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class UserProfileActivity extends AppCompatActivity {

    private CircleImageView profilePicture;
    private TextView profileName, profileGrade, profileSchool;
    private TextView numberOfQuestions, numberOfPoints, numberOfComrades;
    private Button addComrade;
    private TextView percent1, percent2, percent3, subject1, subject2, subject3;
    private RecyclerView profileRecycler;
    private String shortName, userId, displayName, displayPicture;

    private DatabaseReference userIdRef;
    private String myUserId, myDisplayPicture, myDisplayName, myShortName;
    private FirebaseAuth mAuth;
    private String comradeship = "addComrade";

    private Boolean statusFound = false;

    private DatabaseReference myUserIdRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        initializeFields();

        userIdRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(shortName).child(userId);

        myUserIdRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(myShortName).child(myUserId);

        checkStatus();

        userIdRef.addValueEventListener(populateView);

        addComrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addFriend();
            }
        });

    }

    private void addFriend() {

        if(comradeship.equals("addComrade")){

            HashMap<String, Object> map = new HashMap<>();
            map.put("displayName", myDisplayName);
            map.put("displayPicture", myDisplayPicture);
            map.put("userId", myUserId);

            userIdRef.child("requests").child(myUserId).setValue(map)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                comradeship = "cancel";
                                addComrade.setText("cancel request");
                                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_clear_black_24dp, 0,0,0);
                            }
                        }
                    });


        }else if(comradeship.equals("unfriend")){

            userIdRef.child("comrades").child(myUserId).removeValue();//unfriending
            myUserIdRef.child("comrades").child(userId).removeValue()
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                comradeship = "addComrade";
                                addComrade.setText("add comrade");
                                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_person_add_black_24dp, 0,0,0);
                            }
                        }
                    });



        }else if(comradeship.equals("accept")){

            myUserIdRef.child("requests").child(userId).removeValue();

            HashMap<String, Object> myMap = new HashMap<>();
            myMap.put("displayName", myDisplayName);
            myMap.put("displayPicture", myDisplayPicture);
            myMap.put("userId", myUserId);

            HashMap<String, Object> theyMap = new HashMap<>();
            theyMap.put("displayName", displayName);
            theyMap.put("displayPicture", displayPicture);
            theyMap.put("userId", userId);

            myUserIdRef.child("comrades").child(userId).setValue(theyMap);
            userIdRef.child("comrades").child(myUserId).setValue(myMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                comradeship = "unfriend";
                                addComrade.setText("unfriend");
                                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_clear_black_24dp, 0,0,0);
                            }
                        }
                    });


        }else if(comradeship.equals("cancel")){

            userIdRef.child("requests").child(myUserId).removeValue()
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                comradeship = "addComrade";
                                addComrade.setText("add comrade");
                                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_person_add_black_24dp, 0,0,0);
                            }
                        }
                    });

        }
    }

    private void checkStatus() {

        if(statusFound == false){
            userIdRef.child("comrades").child(myUserId).addValueEventListener(unfriendComrade);
        }if(statusFound == false){
            userIdRef.child("requests").child(myUserId).addValueEventListener(cancelRequest);
        }if(statusFound == false){
            myUserIdRef.child("requests").child(userId).addValueEventListener(acceptRequest);
        }

    }

    ValueEventListener acceptRequest = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){
                comradeship = "accept";
                statusFound = true;
                addComrade.setText("accept");
                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_done_black_24dp, 0,0,0);
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };
    ValueEventListener cancelRequest = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){
                comradeship = "cancel";
                statusFound = true;
                addComrade.setText("cancel request");
                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_clear_black_24dp, 0,0,0);
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };
    ValueEventListener unfriendComrade = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){
                comradeship = "unfriend";
                statusFound = true;
                addComrade.setText("unfriend");
                addComrade.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_clear_black_24dp, 0,0,0);
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

    private void initializeFields() {

        profilePicture = findViewById(R.id.profilePicture);
        profileName = findViewById(R.id.profileName);
        profileGrade = findViewById(R.id.profileGrade);
        profileSchool = findViewById(R.id.profileSchool);
        numberOfQuestions = findViewById(R.id.numberOfQuestions);
        numberOfComrades = findViewById(R.id.numberOfComrades);
        numberOfPoints = findViewById(R.id.numberOfPoints);
        addComrade = findViewById(R.id.addComrade);
        percent1 = findViewById(R.id.percent1);
        percent2 = findViewById(R.id.percent2);
        percent3 = findViewById(R.id.percent3);
        subject1 = findViewById(R.id.subject1);
        subject2 = findViewById(R.id.subject2);
        subject3 = findViewById(R.id.subject3);
        profileRecycler = findViewById(R.id.profileRecycler);

        if(getIntent().hasExtra("shortName") && getIntent().hasExtra("userId")){

            shortName = getIntent().getExtras().get("shortName").toString();
            userId = getIntent().getExtras().get("userId").toString();
            displayName = getIntent().getExtras().get("displayName").toString();
            displayPicture = getIntent().getExtras().get("displayPicture").toString();

            myUserId = getIntent().getExtras().get("myUserId").toString();
            myDisplayName = getIntent().getExtras().get("myDisplayName").toString();
            myDisplayPicture = getIntent().getExtras().get("myDisplayPicture").toString();
            myShortName = getIntent().getExtras().get("myShortName").toString();

        }

        mAuth = FirebaseAuth.getInstance();

        myDisplayName = mAuth.getCurrentUser().getDisplayName();
        myDisplayPicture = mAuth.getCurrentUser().getPhotoUrl().toString();
        myUserId = mAuth.getUid();

    }

    ValueEventListener populateView = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            if(dataSnapshot.exists()){

                profileName.setText(dataSnapshot.child("username").getValue().toString());
                profileSchool.setText(dataSnapshot.child("school").getValue().toString());
                profileGrade.setText(dataSnapshot.child("grade").getValue().toString());

            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

}
